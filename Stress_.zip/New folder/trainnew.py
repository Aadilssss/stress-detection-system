import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import load_model, Sequential
from tensorflow.keras.layers import Dense, Dropout, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import ModelCheckpoint
from tensorflow.keras.preprocessing.image import img_to_array

# --------------------------------------------
# CONFIG
# --------------------------------------------
FEEDBACK_DIR = "feedback_dataset"
EMOTIONS = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]

MODEL_PATH = "emotion_model.h5"
NEW_MODEL_PATH = "emotion_model_v2.h5"
BACKUP_PATH = "emotion_model_BACKUP.h5"


# --------------------------------------------
# LOAD FEEDBACK IMAGES
# --------------------------------------------
def load_feedback_data():
    X = []
    y = []

    print("\n📁 Loading feedback dataset...")

    for emotion in EMOTIONS:
        emo_path_correct = os.path.join(FEEDBACK_DIR, "Correct", emotion)
        emo_path_manual = os.path.join(FEEDBACK_DIR, "Manual", emotion)

        for folder in [emo_path_correct, emo_path_manual]:
            if os.path.exists(folder):
                for img_name in os.listdir(folder):
                    img_path = os.path.join(folder, img_name)
                    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

                    if img is None:
                        continue

                    img = cv2.resize(img, (48, 48))
                    img = img_to_array(img) / 255.0

                    X.append(img)
                    y.append(EMOTIONS.index(emotion))

    X = np.array(X)
    y = np.array(y)

    print(f"✅ Loaded {len(X)} images from feedback dataset.")
    return X, y


# --------------------------------------------
# BUILD SMALL CNN HEAD FOR TRANSFER LEARNING
# --------------------------------------------
def build_new_head(base_output_shape):
    model = Sequential()
    model.add(Flatten(input_shape=base_output_shape))
    model.add(Dense(256, activation='relu'))
    model.add(Dropout(0.4))
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.3))
    model.add(Dense(len(EMOTIONS), activation='softmax'))
    return model


# --------------------------------------------
# TRAINING SCRIPT
# --------------------------------------------
def retrain_model():
    # Load data
    X, y = load_feedback_data()
    if len(X) < 20:
        print("\n⚠️ Not enough feedback samples to retrain. Add more data!")
        return

    y = to_categorical(y, num_classes=len(EMOTIONS))

    # Train-val split
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    # Load existing model
    print("\n📌 Loading base model...")
    base_model = load_model(MODEL_PATH)
    base_model.trainable = False  # Freeze original layers

    # Build new classifier head
    new_head = build_new_head(base_model.output_shape[1:])
    model = Sequential([base_model, new_head])

    model.compile(
        loss="categorical_crossentropy",
        optimizer=Adam(learning_rate=0.0005),
        metrics=["accuracy"]
    )

    print("\n📊 Starting training...")
    checkpoint = ModelCheckpoint(
        NEW_MODEL_PATH, monitor='val_accuracy',
        save_best_only=True, verbose=1
    )

    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=15,
        batch_size=32,
        callbacks=[checkpoint]
    )

    # Backup old model
    os.rename(MODEL_PATH, BACKUP_PATH)
    os.rename(NEW_MODEL_PATH, MODEL_PATH)

    print("\n🎉 Training completed!")
    print("📌 New model saved as:", MODEL_PATH)
    print("📌 Backup saved as:", BACKUP_PATH)


# --------------------------------------------
# RUN
# --------------------------------------------
if __name__ == "__main__":
    retrain_model()
