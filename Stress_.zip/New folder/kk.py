import os
print(os.path.exists("C:/Users/mdadi/Downloads/stress_app_flask_auth/stress_app/stress_model.h5"))
