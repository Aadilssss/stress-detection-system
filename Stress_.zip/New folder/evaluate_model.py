import cv2
import numpy as np
from tensorflow.keras.models import load_model

# Load model
model = load_model("emotion_model.h5")

# Emotions
EMOTIONS = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]

def predict(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (48, 48))
    img = resized.reshape(1, 48, 48, 1) / 255.0
    preds = model.predict(img, verbose=0)[0]
    return preds, EMOTIONS[np.argmax(preds)]

# FORCE USE OF DROIDCAM (virtual webcam)
cap = None
for index in [0, 1, 2, 3]:
    cam = cv2.VideoCapture(index, cv2.CAP_DSHOW)
    if cam.isOpened():
        ret, frame = cam.read()
        if ret:
            cap = cam
            print(f"Using camera index {index}")
            break
        cam.release()

if cap is None:
    print("❌ No camera found. Open DroidCam client first!")
    exit()

print("😀 Webcam Accuracy Test Running — Press Q to exit")

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    preds, label = predict(frame)

    # Show dominant emotion
    cv2.putText(frame, f"{label}", (10, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3)

    # Show all emotion percentages on screen
    y_offset = 80
    for i, emotion in enumerate(EMOTIONS):
        percent = round(preds[i] * 100, 2)
        text = f"{emotion}: {percent}%"
        cv2.putText(frame, text, (10, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        y_offset += 30

    # Display frame
    cv2.imshow("Real-Time Accuracy Test (Press Q)", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
