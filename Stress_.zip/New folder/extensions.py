from flask_login import LoginManager
from pymongo import MongoClient

# -----------------------------
# Flask-Login
# -----------------------------
login_manager = LoginManager()
login_manager.login_view = "auth.login"

# -----------------------------
# MongoDB
# -----------------------------
_mongo_db = None  # internal variable

def init_mongo(uri, db_name):
    """Initialize MongoDB connection globally"""
    global _mongo_db
    client = MongoClient(uri)
    _mongo_db = client[db_name]

def get_db():
    """Return the current MongoDB database"""
    return _mongo_db
