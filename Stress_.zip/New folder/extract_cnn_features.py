import os
import cv2
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array

# ✅ Automatically find the emotion_model.h5 in the same folder
MODEL_PATH = os.path.join(os.path.dirname(__file__), "emotion_model.h5")

if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"❌ 'emotion_model.h5' not found at {MODEL_PATH}")
else:
    print(f"✅ Model found at: {MODEL_PATH}")

# Load the pre-trained CNN model
model = load_model(MODEL_PATH)
print("✅ Model loaded successfully!")

# Path to the video file (update this to your video file name)
video_path = "input_video.mp4"

if not os.path.exists(video_path):
    raise FileNotFoundError(f"❌ Video file not found: {video_path}")

# Initialize the face detector
face_cascade = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

# Open video
cap = cv2.VideoCapture(video_path)
frame_features = []

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        face = gray[y:y+h, x:x+w]
        face = cv2.resize(face, (48, 48))
        face = face.astype("float") / 255.0
        face = img_to_array(face)
        face = np.expand_dims(face, axis=0)

        # Extract CNN features (last layer before classification)
        features = model.predict(face)
        frame_features.append(features.flatten())

cap.release()
cv2.destroyAllWindows()

# ✅ Save features for LSTM training
output_path = "cnn_features.npy"
np.save(output_path, np.array(frame_features))
print(f"✅ CNN features extracted and saved to {output_path}")
