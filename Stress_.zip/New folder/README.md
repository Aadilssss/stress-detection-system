# Stress Detector — Flask Auth Starter

This is a minimal Flask app with **user registration & login** ready for your Stress Detection project.

## Quick start

1) Create a virtual env and install deps
```bash
cd stress_app
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

2) Configure environment (optional)
```bash
cp .env.example .env
# edit SECRET_KEY if you want
```

3) Run the app
```bash
python app.py
# open http://127.0.0.1:5000
```

## What’s included
- Flask blueprints (`auth`, `main`)
- SQLite via SQLAlchemy
- Secure password hashing
- CSRF protection via Flask-WTF
- Login required example at `/dashboard`

## Next steps
- Add routes to upload an image and run your trained CNN (`stress_model.h5`)
- Store predictions in DB (create a `Prediction` model)
- Plot user trends on dashboard
```
