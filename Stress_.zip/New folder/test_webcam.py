import cv2
import numpy as np
from tensorflow.keras.models import load_model

MODEL_PATH = "emotion_model.h5"
model = load_model(MODEL_PATH)

EMOTIONS = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]

def get_prediction(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    resized = cv2.resize(gray, (48, 48))
    input_img = resized.reshape(1, 48, 48, 1) / 255.0
    preds = model.predict(input_img, verbose=0)[0]
    results = {EMOTIONS[i]: float(preds[i]) * 100 for i in range(len(EMOTIONS))}
    dominant = max(results, key=results.get)
    return dominant, results

# Force OpenCV to use DroidCam by device name
cap = cv2.VideoCapture('video=DroidCam Source 1', cv2.CAP_DSHOW)

if not cap.isOpened():
    print("❌ Cannot open DroidCam Source 1, trying Source 2...")
    cap = cv2.VideoCapture('video=DroidCam Source 2', cv2.CAP_DSHOW)

if not cap.isOpened():
    print("❌ Cannot access DroidCam. Open DroidCam client first!")
    exit()

print("✅ Using DroidCam. Press Q to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    dominant, results = get_prediction(frame)
    cv2.putText(frame, dominant, (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0,255,0), 3)

    cv2.imshow("Emotion Test (Press Q)", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
