from flask import Blueprint, render_template, request, jsonify, redirect, url_for, send_file, current_app
from flask_login import login_required, current_user
from tensorflow.keras.models import load_model
import numpy as np
import cv2
import base64
import os
import tempfile
from extensions import get_db
from datetime import datetime, timedelta
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import traceback

main = Blueprint("main", __name__)

# --------------------------
# MongoDB collections
# --------------------------
def survey_collection():
    return get_db()["survey_results"]

def dashboard_collection():
    return get_db()["dashboard_results"]

def video_collection():
    return get_db()["video_results"]

def chat_collection():
    return get_db()["chat_history"]

def chronic_report_collection():
    return get_db()["chronic_reports"]

def feedback_collection():
    return get_db()["feedback_results"]

# --------------------------
# Model load (safely)
# --------------------------
MODEL_PATH = os.path.join(os.path.dirname(__file__), "emotion_model.h5")
if os.path.exists(MODEL_PATH):
    try:
        model = load_model(MODEL_PATH)
    except Exception as e:
        # Fail fast with clear message
        raise RuntimeError(f"Failed to load model at {MODEL_PATH}: {e}")
else:
    raise FileNotFoundError(f"❌ emotion_model.h5 not found at {MODEL_PATH}")

# Emotion labels (must match training order)
EMOTIONS = ["Angry", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]

# --------------------------
# Stress scoring weights
# --------------------------
WEIGHTS = {
    "Angry": 1.0,
    "Fear": 0.9,
    "Sad": 0.8,
    "Disgust": 0.6,
    "Neutral": 0.5,
    "Surprise": 0.3,
    "Happy": 0.1,
}

def compute_stress(results):
    """
    results: dict {emotion: confidence_percent}
    returns: (score_percent (0-100), level_string)
    """
    try:
        s = 0.0
        for e, v in results.items():
            w = WEIGHTS.get(e, 0.5)
            s += (v * w)
        # results values are percentages (0..100). Normalize by total weight * 100
        total_weight = sum(WEIGHTS.get(e, 0.5) for e in EMOTIONS)
        # produce a 0-100 percentage
        score = (s / (100.0 * total_weight)) * 100.0
        score = max(0.0, min(100.0, round(score, 2)))
        if score >= 70:
            level = "High Stress 😟"
        elif score >= 40:
            level = "Moderate Stress 😐"
        else:
            level = "Low Stress 😌"
        return score, level
    except Exception:
        return 0.0, "Unknown"

# --------------------------
# Utility helpers
# --------------------------
def decode_base64_dataurl(data_url):
    """
    Accepts a data URL like "data:video/webm;base64,AAAA..."
    Returns: (mime_type, bytes)
    """
    if not data_url or "," not in data_url:
        return None, None
    header, b64 = data_url.split(",", 1)
    try:
        mime = header.split(":")[1].split(";")[0]
    except Exception:
        mime = None
    try:
        raw = base64.b64decode(b64)
    except Exception:
        return mime, None
    return mime, raw

def save_bytes_to_tempfile(b, suffix):
    tf = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tf.write(b)
        tf.flush()
        tf.close()
        return tf.name
    except Exception:
        try:
            tf.close()
        except:
            pass
        raise

def safe_remove(path):
    try:
        os.remove(path)
    except Exception:
        pass

# --------------------------
# ROUTES
# --------------------------
@main.route("/")
def index():
    return render_template("index.html")

@main.route("/home")
@login_required
def home():
    return render_template("home.html", user=current_user)

# --------------------------
# Dashboard - image & webcam
# --------------------------
@main.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    results = None
    prediction = None
    stress_score = None
    stress_level = None

    if request.method == "POST":
        try:
            img = None
            # Uploaded file
            if "image" in request.files:
                file = request.files["image"]
                if file and file.filename:
                    data = file.read()
                    nparr = np.frombuffer(data, np.uint8)
                    img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)

            # Webcam image (dataURL)
            elif "webcam_image" in request.form:
                data_url = request.form.get("webcam_image", "")
                if data_url and "," in data_url:
                    _, b = data_url.split(",", 1)
                    try:
                        img_bytes = base64.b64decode(b)
                        nparr = np.frombuffer(img_bytes, np.uint8)
                        img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
                    except Exception:
                        img = None

            if img is not None:
                # preprocess
                img = cv2.resize(img, (48, 48))[None, ..., None] / 255.0
                preds = model.predict(img, verbose=0)[0]
                # convert to percent and ensure sum normalization
                raw_results = {EMOTIONS[i]: float(preds[i]) * 100.0 for i in range(len(EMOTIONS))}
                # normalize to sum 100 (avoid tiny numerical drift)
                s = sum(raw_results.values()) or 1.0
                results = {k: round((v / s) * 100.0, 2) for k, v in raw_results.items()}
                prediction = max(results, key=results.get)
                stress_score, stress_level = compute_stress(results)

                # store
                dashboard_collection().insert_one({
                    "user_id": str(current_user.id),
                    "results": results,
                    "prediction": prediction,
                    "stress_score": stress_score,
                    "stress_level": stress_level,
                    "timestamp": datetime.now()
                })
        except Exception as e:
            current_app.logger.error("Dashboard processing error: %s\n%s", str(e), traceback.format_exc())

    return render_template("dashboard.html",
                           user=current_user,
                           prediction=prediction,
                           results=results,
                           stress_score=stress_score,
                           stress_level=stress_level)

# --------------------------
# Feedback endpoint (frontend collects original + corrected)
# --------------------------
@main.route("/feedback", methods=["POST"])
@login_required
def feedback():
    try:
        data = request.get_json() or {}
        predicted = data.get("predicted")
        actual = data.get("actual")  # if None -> user accepted predicted
        original_results = data.get("original_results")
        corrected_results = data.get("corrected_results")
        img_data = data.get("image", "")

        # decode saved frame if provided
        img_np = None
        try:
            if isinstance(img_data, str) and "," in img_data:
                mime, raw = decode_base64_dataurl(img_data)
                if raw:
                    arr = np.frombuffer(raw, np.uint8)
                    img_np = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        except Exception:
            img_np = None

        # compute corrected stress (if provided)
        corrected_stress_score, corrected_stress_level = None, None
        if corrected_results:
            try:
                corrected_stress_score, corrected_stress_level = compute_stress(corrected_results)
            except Exception:
                corrected_stress_score, corrected_stress_level = None, None

        # insert into DB
        feedback_collection().insert_one({
            "user_id": str(current_user.id),
            "predicted": predicted,
            "actual": actual if actual else predicted,
            "original_results": original_results,
            "corrected_results": corrected_results,
            "corrected_stress_score": corrected_stress_score,
            "corrected_stress_level": corrected_stress_level,
            "timestamp": datetime.now()
        })

        # save image under feedback_dataset/<label>/
        if img_np is not None:
            base_dir = os.path.join(os.path.dirname(__file__), "feedback_dataset")
            label = actual if actual else predicted
            path = os.path.join(base_dir, label)
            os.makedirs(path, exist_ok=True)
            fname = datetime.now().strftime("%Y%m%d_%H%M%S") + ".jpg"
            cv2.imwrite(os.path.join(path, fname), img_np)

        return jsonify({"message": "Feedback saved successfully!"})
    except Exception as e:
        current_app.logger.error("Feedback error: %s\n%s", str(e), traceback.format_exc())
        return jsonify({"message": "Failed to save feedback", "error": str(e)}), 500

# --------------------------
# Chronic survey (unchanged)
# --------------------------
@main.route("/chronic_survey", methods=["GET", "POST"])
@login_required
def chronic_survey():
    score = None
    message = None
    if request.method == "POST":
        try:
            answers = [int(request.form.get(f"q{i}", 0)) for i in range(1, 6)]
            score = sum(answers)
            if score <= 15:
                message = "You seem calm and relaxed today 😌"
            elif score <= 30:
                message = "You’re somewhat stressed. Try relaxing activities ☕"
            else:
                message = "High stress detected! Take time to unwind 💆‍♂️"
            survey_collection().insert_one({
                "user_id": str(current_user.id),
                "score": score,
                "message": message,
                "timestamp": datetime.now()
            })
            save_chronic_result(str(current_user.id), survey_score=score)
        except Exception as e:
            current_app.logger.error("chronic_survey error: %s", str(e))
            message = f"Error: {e}"
    return render_template("chronic_survey.html", user=current_user, score=score, message=message)

# --------------------------
# Chronic video analysis
# - Supports webm/mp4 from browser
# - Processes frames with skipping (faster)
# - Configurable max duration and frame skip
# --------------------------
@main.route("/chronic_video", methods=["GET", "POST"])
@login_required
def chronic_video():
    """
    POST expects JSON: { "videoData": "data:video/webm;base64,..." }
    Returns JSON with prediction summary.
    """
    if request.method == "POST":
        try:
            data = request.get_json() or {}
            video_data_url = data.get("videoData", "")

            if not video_data_url or "," not in video_data_url:
                return jsonify({"error": "No video data received"}), 400

            mime, raw = decode_base64_dataurl(video_data_url)
            if raw is None:
                return jsonify({"error": "Invalid base64 video data"}), 400

            # write to temp file with appropriate suffix
            suffix = ".webm" if (mime and "webm" in mime) else ".mp4"
            tmp_path = save_bytes_to_tempfile(raw, suffix=suffix)

            # Config: adjust for performance
            MAX_SECONDS = 60            # maximum seconds to accept/process (browser side should enforce)
            FRAME_SKIP = 2              # process every (FRAME_SKIP+1)th frame => e.g., 2 => every 3rd frame
            MAX_FRAMES_TO_PROCESS = 300 # safety cap

            cap = cv2.VideoCapture(tmp_path)
            if not cap.isOpened():
                safe_remove(tmp_path)
                return jsonify({"error": "Cannot open saved video file"}), 500

            fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            duration_seconds = total_frames / fps if fps else None

            frames = []
            frame_count = 0
            processed = 0
            max_frame_allowed = int(MAX_SECONDS * fps) if fps else None

            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                frame_count += 1

                if max_frame_allowed and frame_count > max_frame_allowed:
                    break

                if (frame_count % (FRAME_SKIP + 1)) != 0:
                    continue

                try:
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    resized = cv2.resize(gray, (48, 48))[None, ..., None] / 255.0
                    preds = model.predict(resized, verbose=0)[0]
                    frames.append(preds)
                    processed += 1
                except Exception:
                    continue

                if processed >= MAX_FRAMES_TO_PROCESS:
                    break

            cap.release()
            safe_remove(tmp_path)

            if not frames:
                return jsonify({"error": "No frames processed"}), 400

            # average across frames
            avg = np.mean(frames, axis=0)
            results = {EMOTIONS[i]: round(float(avg[i]) * 100.0, 2) for i in range(len(EMOTIONS))}
            # normalize to 100
            s = sum(results.values()) or 1.0
            results = {k: round((v / s) * 100.0, 2) for k, v in results.items()}

            dominant = max(results, key=results.get)
            stress_score, stress_level = compute_stress(results)

            # save record
            video_collection().insert_one({
                "user_id": str(current_user.id),
                "dominant_emotion": dominant,
                "results": results,
                "stress_score": stress_score,
                "stress_level": stress_level,
                "timestamp": datetime.now()
            })

            save_chronic_result(str(current_user.id), video_score=stress_score)

            return jsonify({
                "prediction": dominant,
                "results": results,
                "stress_score": stress_score,
                "stress_level": stress_level
            })

        except Exception as e:
            current_app.logger.error("chronic_video error: %s\n%s", str(e), traceback.format_exc())
            return jsonify({"error": str(e)}), 500

    # GET -> render template
    return render_template("chronic_video.html", user=current_user)

# --------------------------
# Chatbot endpoints (fixed)
# --------------------------
# --------------------------
# Chatbot (Upgraded Smart AI Replies)
# --------------------------

@main.route("/chatbot")
@login_required
def chatbot_page():
    """Serves the chatbot UI page"""
    return render_template("chatbot.html", user=current_user)


@main.route("/chatbot_reply", methods=["POST"])
@login_required
def chatbot_reply():
    import random

    data = request.get_json() or {}
    msg = data.get("message", "").lower().strip()

    def pick(lst):
        return random.choice(lst)

    # ---------------------------------------------------
    # Keyword Categories
    # ---------------------------------------------------
    stress = ["stress", "stressed", "pressure", "tension", "overload", "burden"]
    sad = ["sad", "down", "hurt", "cry", "crying", "depressed", "empty"]
    angry = ["angry", "mad", "irritated", "annoyed", "frustrated", "pissed"]
    tired = ["tired", "exhausted", "sleepy", "drained", "fatigue", "burnout"]
    anxious = ["anxiety", "anxious", "fear", "scared", "panic", "nervous"]
    confused = ["confused", "lost", "idk", "don't know", "unsure"]
    study = ["study", "exam", "studies", "college", "test", "fail", "marks"]
    heartbreak = ["breakup", "heartbreak", "love", "relationship", "cheated"]
    lonely = ["lonely", "alone", "no one", "nobody", "isolated"]
    overthink = ["overthinking", "over think", "thinking too much", "thoughts"]
    happy = ["happy", "good", "great", "awesome", "better", "fine"]

    # ---------------------------------------------------
    # Response Packs
    # ---------------------------------------------------

    RESP_STRESS = [
        "😟 That sounds really stressful… want to tell me what triggered it?",
        "🌿 I'm here. Stress feels heavy, but sharing it lightens it.",
        "💛 Take a breath… you can talk to me, I won’t judge.",
        "🤍 You’re handling a lot… tell me what’s making it hard today."
    ]

    RESP_SAD = [
        "💙 I'm really sorry you're feeling this way… what happened?",
        "🌧️ You don’t have to face sadness alone. I'm here.",
        "🤍 It’s okay to feel low… want to tell me what’s hurting you?",
        "💫 I’m here, safe space… talk to me."
    ]

    RESP_ANGRY = [
        "🔥 Something must have really upset you. Want to share it?",
        "😤 Anger builds up… letting it out helps. Tell me.",
        "💬 You don’t have to hold it in. What caused this anger?",
        "🌩️ I get it… anger can be overwhelming. I'm listening."
    ]

    RESP_TIRED = [
        "😴 You must be drained… did you push yourself today?",
        "🛌 It’s okay to rest. Your body needs care.",
        "🌙 You sound exhausted… what tired you out?",
        "💤 Burnout is real… talk to me, I'm here."
    ]

    RESP_ANXIOUS = [
        "😣 Anxiety is tough… want to tell me what caused it?",
        "🌫️ It's okay… breathe slowly. What made you anxious?",
        "💛 I'm right here. You're not alone in this feeling.",
        "🤍 Anxiety doesn't define you. Tell me what’s worrying you."
    ]

    RESP_CONFUSED = [
        "😕 It's okay to feel confused… want to talk it through?",
        "🔍 Let's figure it out together. What's on your mind?",
        "💭 Confusion means you're thinking deeply… tell me more.",
        "🤔 What part feels unclear to you?"
    ]

    RESP_STUDY = [
        "📚 Studying can be overwhelming… what subject is stressing you?",
        "🧠 Exams are tough, but you’re tougher. Tell me what’s worrying you.",
        "✨ I believe in you… what part feels difficult?",
        "⏳ It's okay to not understand everything immediately. Talk to me."
    ]

    RESP_HEARTBREAK = [
        "💔 I'm really sorry… heart pain is the worst. Want to share what happened?",
        "🤍 Breakups hurt deeply… you don’t have to face it alone.",
        "🌧️ You deserved better. I'm here to listen.",
        "🫂 Healing takes time… talk to me, I'm here."
    ]

    RESP_LONELY = [
        "🤍 You’re not alone — I’m here with you.",
        "🌙 Loneliness can hurt… want to talk about it?",
        "💛 I'm here. You matter more than you think.",
        "🫂 You’re not alone anymore. I'm listening."
    ]

    RESP_OVERTHINK = [
        "🌪️ Overthinking is exhausting… what thoughts are looping?",
        "🧘 Let's slow down… tell me what’s repeating in your mind.",
        "💭 Your mind is overloaded… share it with me?",
        "🤍 You don’t have to carry all those thoughts alone."
    ]

    RESP_HAPPY = [
        "😊 I’m so glad you’re feeling good! What made your day?",
        "✨ Love that energy! Tell me more :)",
        "🌼 That’s awesome — keep shining!",
        "💛 Hearing this makes me happy too!"
    ]

    RESP_GENERAL = [
        "💬 I'm here… tell me more.",
        "🌿 Go on, I’m listening.",
        "🤍 You can talk to me.",
        "✨ What’s on your mind?",
        "💫 I’m here for you, talk to me."
    ]

    # ---------------------------------------------------
    # Matching Logic
    # ---------------------------------------------------

    reply = pick(RESP_GENERAL)  # default fallback

    if any(w in msg for w in stress):
        reply = pick(RESP_STRESS)
    elif any(w in msg for w in sad):
        reply = pick(RESP_SAD)
    elif any(w in msg for w in angry):
        reply = pick(RESP_ANGRY)
    elif any(w in msg for w in tired):
        reply = pick(RESP_TIRED)
    elif any(w in msg for w in anxious):
        reply = pick(RESP_ANXIOUS)
    elif any(w in msg for w in confused):
        reply = pick(RESP_CONFUSED)
    elif any(w in msg for w in study):
        reply = pick(RESP_STUDY)
    elif any(w in msg for w in heartbreak):
        reply = pick(RESP_HEARTBREAK)
    elif any(w in msg for w in lonely):
        reply = pick(RESP_LONELY)
    elif any(w in msg for w in overthink):
        reply = pick(RESP_OVERTHINK)
    elif any(w in msg for w in happy):
        reply = pick(RESP_HAPPY)

    # ---------------------------------------------------
    # Save Chat to DB
    # ---------------------------------------------------
    try:
        chat_collection().insert_one({
            "user_id": str(current_user.id),
            "user_message": msg,
            "bot_reply": reply,
            "timestamp": datetime.now()
        })
    except Exception:
        current_app.logger.error("Chat insert error")

    return jsonify({"reply": reply})


@main.route("/reset_chat", methods=["POST"])
@login_required
def reset_chat():
    chat_collection().delete_many({"user_id": str(current_user.id)})
    return jsonify({"message": "Chat cleared"})

# --------------------------
# Chronic stress navigation + report pages (unchanged)
# --------------------------
@main.route("/chronic_stress")
@login_required
def chronic_stress():
    return render_template("chronic_stress.html", user=current_user)

@main.route("/chronic_stress_video")
@login_required
def chronic_stress_video():
    return redirect(url_for("main.chronic_video"))

@main.route("/chronic_stress_survey")
@login_required
def chronic_stress_survey():
    return redirect(url_for("main.chronic_survey"))

@main.route("/chronic_stress_sensor")
@login_required
def chronic_stress_sensor():
    return redirect(url_for("main.chronic_stress_report"))

@main.route("/chronic_stress_report")
@login_required
def chronic_stress_report():
    db = chronic_report_collection()
    user_id = str(current_user.id)
    week_ago = datetime.now() - timedelta(days=7)
    records = list(db.find({
        "user_id": user_id,
        "date": {"$gte": week_ago.strftime("%Y-%m-%d")}
    }).sort("date", 1))
    total = 0.0
    count = 0
    for r in records:
        if r.get("combined_stress") is not None:
            total += r["combined_stress"]
            count += 1
    weekly_avg = round(total / count, 2) if count > 0 else None
    return render_template("generate_report.html", user=current_user, records=records, weekly_avg=weekly_avg)

# --------------------------
# Delete / Download
# --------------------------
@main.route("/delete_chronic_entry/<date>", methods=["POST"])
@login_required
def delete_chronic_entry(date):
    db = chronic_report_collection()
    user_id = str(current_user.id)
    db.delete_one({"user_id": user_id, "date": date})
    return redirect(url_for("main.chronic_stress_report"))

@main.route("/download_weekly_report")
@login_required
def download_weekly_report():
    db = chronic_report_collection()
    user_id = str(current_user.id)
    week_ago = datetime.now() - timedelta(days=7)
    records = list(db.find({
        "user_id": user_id,
        "date": {"$gte": week_ago.strftime("%Y-%m-%d")}
    }).sort("date", 1))
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph("🧠 Weekly Chronic Stress Report", styles["Title"]))
    story.append(Spacer(1, 12))
    data = [["Date", "Survey Stress (%)", "Video Stress (%)", "Combined (%)"]]
    for r in records:
        data.append([
            r.get("date", "-"),
            r.get("survey_stress", "-"),
            r.get("video_stress", "-"),
            r.get("combined_stress", "-"),
        ])
    table = Table(data)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#007BFF")),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('BACKGROUND', (0, 1), (-1, -1), colors.whitesmoke),
    ]))
    story.append(table)
    total, count = 0, 0
    for r in records:
        if r.get("combined_stress"):
            total += r["combined_stress"]
            count += 1
    weekly_avg = round(total / count, 2) if count > 0 else None
    story.append(Spacer(1, 20))
    if weekly_avg:
        story.append(Paragraph(f"<b>Weekly Average Stress:</b> {weekly_avg}%", styles["Normal"]))
    else:
        story.append(Paragraph("No data available for this week.", styles["Normal"]))
    doc.build(story)
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name="Weekly_Stress_Report.pdf", mimetype="application/pdf")

# --------------------------
# Helper used earlier - save chronic combined result
# --------------------------
def save_chronic_result(user_id, survey_score=None, video_score=None):
    today = datetime.now().strftime("%Y-%m-%d")
    db = chronic_report_collection()
    report = db.find_one({"user_id": user_id, "date": today})
    if report:
        update_fields = {}
        if survey_score is not None:
            update_fields["survey_stress"] = survey_score
        if video_score is not None:
            update_fields["video_stress"] = video_score
        if update_fields:
            db.update_one({"_id": report["_id"]}, {"$set": update_fields})
        updated = db.find_one({"_id": report["_id"]})
        if updated.get("survey_stress") and updated.get("video_stress"):
            avg = (updated["survey_stress"] + updated["video_stress"]) / 2
            db.update_one({"_id": report["_id"]}, {"$set": {"combined_stress": avg}})
    else:
        data = {
            "user_id": user_id,
            "date": today,
            "survey_stress": survey_score,
            "video_stress": video_score,
            "combined_stress": None
        }
        if survey_score is not None and video_score is not None:
            data["combined_stress"] = (survey_score + video_score) / 2
        db.insert_one(data)
