import os
from flask import Flask
from extensions import init_mongo, login_manager
from auth import auth
from main import main
from pymongo.errors import ServerSelectionTimeoutError

# -----------------------------
# MongoDB Connection
# -----------------------------
MONGO_USER = os.getenv("MONGO_USER", "mdadilkhateeb2_db_user")
MONGO_PASSWORD = os.getenv("MONGO_PASSWORD", "Aadil%40123")
MONGO_CLUSTER = os.getenv("MONGO_CLUSTER", "cluster0.jz7neps.mongodb.net")
MONGO_DB = os.getenv("MONGO_DB", "stressDB")

mongo_uri = f"mongodb+srv://{MONGO_USER}:{MONGO_PASSWORD}@{MONGO_CLUSTER}/{MONGO_DB}?retryWrites=true&w=majority"

try:
    init_mongo(mongo_uri, MONGO_DB)
    print("✅ MongoDB Atlas connected successfully!")
except ServerSelectionTimeoutError:
    print("⚠️ Atlas connection failed, using local MongoDB...")
    init_mongo("mongodb://localhost:27017", MONGO_DB)
    print("✅ Connected to local MongoDB!")

# -----------------------------
# Flask App Setup
# -----------------------------
def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret")
    
    # Initialize Flask-Login
    login_manager.init_app(app)

    # Register Blueprints
    app.register_blueprint(auth, url_prefix="/auth")
    app.register_blueprint(main)

    return app

# -----------------------------
# Run Flask
# -----------------------------
if __name__ == "__main__":
    app = create_app()
    app.run(debug=True, host="0.0.0.0", port=5000)
