from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import get_db, login_manager
from bson.objectid import ObjectId

auth = Blueprint("auth", __name__, template_folder="templates")

def users_collection():
    return get_db()["users"]

class User(UserMixin):
    def __init__(self, user_doc):
        self.id = str(user_doc["_id"])
        self.username = user_doc["username"]
        self.email = user_doc["email"]
        self.password_hash = user_doc["password"]

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(user_id):
    user_doc = users_collection().find_one({"_id": ObjectId(user_id)})
    if user_doc:
        return User(user_doc)
    return None

@auth.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))

    if request.method == "POST":
        username = request.form.get("username")
        email = request.form.get("email")
        password = request.form.get("password")

        if users_collection().find_one({"$or": [{"email": email}, {"username": username}]}):
            flash("⚠️ Username or email already exists.", "danger")
            return render_template("register.html")

        users_collection().insert_one({
            "username": username,
            "email": email,
            "password": generate_password_hash(password)
        })

        flash("✅ Account created successfully! Please log in.", "success")
        return redirect(url_for("auth.login"))

    return render_template("register.html")

@auth.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.home"))

    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user_doc = users_collection().find_one({"email": email})

        if user_doc:
            user_obj = User(user_doc)
            if user_obj.check_password(password):
                login_user(user_obj)
                next_page = request.args.get("next")
                return redirect(next_page or url_for("main.home"))

        flash("❌ Invalid email or password.", "danger")

    return render_template("login.html")

@auth.route("/logout")
@login_required
def logout():
    logout_user()
    flash("👋 You have been logged out successfully.", "info")
    return redirect(url_for("auth.login"))
